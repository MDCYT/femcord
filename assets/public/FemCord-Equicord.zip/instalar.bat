@echo off
title Instalador de FemCord (Equicord + InstanceSwitcher)
echo ======================================================================
echo           Instalador de FemCord Client (Equicord Modificado)
echo   Incluye: InstanceSwitcher, plugins de Meowcord y soporte FemCord
echo ======================================================================
echo.

echo 1. Cerrando procesos de Discord (si estan abiertos)...
taskkill /F /IM Discord.exe >nul 2>&1
taskkill /F /IM DiscordCanary.exe >nul 2>&1
taskkill /F /IM DiscordPTB.exe >nul 2>&1
timeout /t 2 /nobreak >nul

echo 2. Registrando parche en Discord con el instalador de Equicord...
"%~dp0EquilotlCli.exe" -install -branch auto
if %errorlevel% neq 0 (
    echo [AVISO] Intentando instalar especificamente en Discord Canary...
    "%~dp0EquilotlCli.exe" -install -branch canary
)

echo 3. Instalando equicord.asar personalizado con plugins...
if not exist "%APPDATA%\Equicord" mkdir "%APPDATA%\Equicord"
copy /Y "%~dp0desktop.asar" "%APPDATA%\Equicord\equicord.asar"
if %errorlevel% neq 0 (
    echo [ERROR] No se pudo copiar equicord.asar a %APPDATA%\Equicord.
    pause
    exit /b %errorlevel%
)

echo.
echo ======================================================================
echo   Instalacion completada con exito!
echo.
echo   Como usar:
echo   - Inicia Discord (o Discord Canary).
echo   - Ve a Ajustes de Usuario -> Plugins.
echo   - Activa el plugin "InstanceSwitcher".
echo   - Presiona Ctrl+Alt+I (o haz click en el icono en la barra superior)
echo     para cambiar entre FemCord y otras instancias de Meowcord/Discord!
echo ======================================================================
echo.
pause
